/*demo wp list js*/
jQuery(document).ready(function($){
	$.validator.addMethod("loginRegex", function(value, element) {
        return this.optional(element) || /^[a-z0-9\-\s]+$/i.test(value);
    }, "Username must contain only letters, numbers, or dashes.");

	$("#demo_form_id").validate({
        rules: {
            name: {required: true, loginRegex:true, maxlength: 30, minlength: 3 },
            email: {required: true, email: true},
            phone: {required: true, number: true}
            
        },
        messages: {
            name: {required: "Please enter name"},
            email: {required: "Please enter email", email: "Please enter valid email"},
            phone: {required: "Please enter phone number"}
            
        },
        submitHandler: function (form,event) {
		event.preventDefault();
		$.ajax({
			
			type: 'post',
            url: ajax_script.ajaxurl,			
			data: $('#demo_form_id').serialize(),
			success: function (result) {
                    
                    console.log(result);
                    /*if (result == "true") {
                        $('#make_notify').html('Thank for your request. We will be in touch with you very soon.');
                        $('#make_notify').attr('class', 'success');
                        $("#make_offer_frm")[0].reset();
                    } else {
                        $('#make_notify').html('Oops!! Something went wrong. Try again.');
                        $('#make_notify').attr('class', 'fail');
                    }*/
//                    setTimeout(function () {
//                        $('#make_notify').html('');
//                        $('#make_notify').attr('class', '');
//                    }, 5000);
            }    

		});
	}
	});
});