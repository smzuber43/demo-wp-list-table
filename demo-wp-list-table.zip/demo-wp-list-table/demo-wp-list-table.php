<?php
/*
 * Plugin Name: Demo Wp List Table
 * Description: An example of how to use the WP_List_Table class to display data in your WordPress Admin area
 * Plugin URI: http://www.smzuber.com
 * Author: smzuber
 * Author URI: http://www.smzuber.com
 * Version: 1.0
 * License: GPL2
 */
 global $demo_wp_table_db_version;
$demo_wp_table_db_version = '1.0';
/**
 * creates db tables
 *
 * @access public
 * @return bool
 */
define('TBL_CUST',$wpdb->prefix. "customers");
function demo_form_activate() {


global $wpdb;
global $make_offer_db_version;
$table_name = $wpdb->prefix. "customers";

$sql = " CREATE TABLE " . $table_name . " (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(50) NOT NULL,
        `email` varchar(75) NOT NULL,
        `phone` varchar(20) NOT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

// we do not execute sql directly
// we are calling dbDelta which cant migrate database
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
dbDelta($sql);

// save current database version for later use (on upgrade)
add_option('demo_wp_table_db_version', $demo_wp_table_db_version);

/**
 * [OPTIONAL] Example of updating to 1.1 version
 *
 * If you develop new version of plugin
 * just increment $make_offer_db_version variable
 * and add following block of code
 *
 * must be repeated for each new version
 * in version 1.1 we change email field
 * to contain 200 chars rather 100 in version 1.0
 * and again we are not executing sql
 * we are using dbDelta to migrate table changes
 */
$installed_ver = get_option('demo_wp_table_db_version');
    if ($installed_ver != $demo_wp_table_db_version) {

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // notice that we are updating option, rather than adding it
    update_option('demo_wp_table_db_version', $demo_wp_table_db_version);
    }
}
register_activation_hook(__FILE__, 'demo_form_activate');

/**
 * Trick to update plugin database, see docs
 */
function demo_form_update_db_check()
{
    global $make_offer_db_version;
    if (get_option('make_offer_db_version') != $make_offer_db_version) {
        fz_make_offer_activate();
    }
}


add_action('plugins_loaded', 'demo_form_update_db_check');


/**
 * uninstalls plugin
 */
function makeoffer_uninstall() {
return;
}

register_uninstall_hook(__FILE__,'makeoffer_uninstall');
 
function demo_enque_styles(){
	wp_enqueue_style( 'demo-style', plugin_dir_url( __FILE__ ) .'assert/css/demo-style.css', false ); 
}

function demo_enque_scripts(){
	wp_enqueue_script( 'demo-jquery.validate.min', plugin_dir_url( __FILE__ ) .'assert/js/jquery.validate.min.js',array('jquery'),'1.0',false ); 
	wp_register_script( 'demo-custom', plugin_dir_url( __FILE__ ) .'assert/js/custom.js',array('jquery'),'1.0',false ); 
	wp_localize_script( 'demo-custom', 'ajax_script', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
	wp_enqueue_script( 'demo-custom' );
// Enqueued script with localized data.

}	

add_action( 'wp_enqueue_scripts', 'demo_enque_styles' );
add_action( 'wp_enqueue_scripts', 'demo_enque_scripts' );

include_once('/admin/admin_setup.php'); 
include_once('/front_demo.php'); 
 
 
 
 
 
 add_action( 'wp_ajax_demo_form', 'demo_submit_form' );
 add_action( 'wp_ajax_nopriv_demo_form', 'demo_submit_form' );
 function demo_submit_form(){
	 global $wpdb;
	 
	$wpdb->insert($wpdb->prefix. "customers", 
	array( 
		'name' => sanitize_text_field($_POST['name']), 
		'email' => sanitize_text_field($_POST['email']), 
		'phone' =>sanitize_text_field($_POST['phone'])
	), 
	array( 
		'%s', 
		'%s', 
		'%d' 
	) 
	);
	 wp_die();
 }
 
